"""
config.py - Central configuration for the Telegram Mock Test Bot.
All settings are read from environment variables for Railway deployment.
"""

import os
from pathlib import Path

# ─────────────────────────────────────────────
# Base Paths
# ─────────────────────────────────────────────
BASE_DIR = Path(__file__).parent
GENERATED_TESTS_DIR = BASE_DIR / "generated_tests"
DATABASE_DIR = BASE_DIR / "database"
TEMPLATES_DIR = BASE_DIR / "templates"

# Ensure directories exist
GENERATED_TESTS_DIR.mkdir(exist_ok=True)
DATABASE_DIR.mkdir(exist_ok=True)

# ─────────────────────────────────────────────
# Telegram Bot
# ─────────────────────────────────────────────
BOT_TOKEN: str = os.environ["BOT_TOKEN"]  # Mandatory – will raise if missing

# Optional webhook settings (Railway sets PORT automatically)
WEBHOOK_URL: str = os.environ.get("WEBHOOK_URL", "")  # e.g. https://your-app.up.railway.app
PORT: int = int(os.environ.get("PORT", 8443))

# ─────────────────────────────────────────────
# Bot Identity
# ─────────────────────────────────────────────
BOT_NAME = "MockTest Pro"
BOT_VERSION = "1.0.0"
CHANNEL_LINK = os.environ.get("CHANNEL_LINK", "https://t.me/yourchannel")
SUPPORT_LINK = os.environ.get("SUPPORT_LINK", "https://t.me/yoursupport")
OWNER_USERNAME = os.environ.get("OWNER_USERNAME", "@owner")

# ─────────────────────────────────────────────
# Database
# ─────────────────────────────────────────────
DATABASE_PATH = DATABASE_DIR / "bot.db"

# ─────────────────────────────────────────────
# Conversation States  (unique integers)
# ─────────────────────────────────────────────
(
    STATE_COLLECTING_TEXT,
    STATE_ASK_TIME,
    STATE_ASK_NEGATIVE,
    STATE_ASK_PASSING,
    STATE_ASK_TITLE,
    STATE_ASK_SUBJECT,
    STATE_ASK_INSTRUCTIONS,
    STATE_ASK_SHUFFLE,
    STATE_ASK_SHOW_RESULT,
    STATE_ASK_DARK_MODE,
    STATE_GENERATING,
) = range(11)

# ─────────────────────────────────────────────
# Limits
# ─────────────────────────────────────────────
MAX_TEXT_ACCUMULATE_CHARS = 500_000   # 500 KB of raw text per session
MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024  # 5 MB

# ─────────────────────────────────────────────
# Logging
# ─────────────────────────────────────────────
LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")
