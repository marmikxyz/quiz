"""
handlers/start.py - /start, /help, /about and main menu callbacks.
"""

import logging
from telegram import Update
from telegram.ext import ContextTypes

from config import BOT_NAME, BOT_VERSION, CHANNEL_LINK, SUPPORT_LINK, OWNER_USERNAME
from database import upsert_user
from utils.keyboards import main_menu_keyboard, back_to_menu_keyboard

logger = logging.getLogger(__name__)

WELCOME_TEXT = """
🎯 *Welcome to {bot_name}!*

Transform your study material into professional interactive mock tests — just like Testbook!

━━━━━━━━━━━━━━━━━━━━
✨ *Features*
━━━━━━━━━━━━━━━━━━━━
📝 Paste text or upload a `.txt` file
⚙️ Custom timer, negative marking & passing marks
🔀 Shuffle questions
📊 Instant result with detailed analysis
🌙 Dark mode support
📱 Mobile-responsive HTML output

━━━━━━━━━━━━━━━━━━━━
👇 *Choose an option below to get started!*
""".strip()

HELP_TEXT = """
❓ *Help — MockTest Pro*

*Commands*
/start  – Main menu
/create – Start creating a new test
/cancel – Cancel current operation
/done   – Finish sending text and proceed
/about  – About this bot

*How to create a test*
1. Click *Create Test* or send /create
2. Paste your MCQ text or upload a `.txt` file
3. Send as many messages as needed (Telegram has length limits)
4. Send /done when you're finished
5. Answer a few configuration questions
6. Receive your interactive HTML mock test!

*Supported Question Format*
```
1. What is the capital of India?
A) Mumbai  B) Delhi  C) Kolkata  D) Chennai
Answer: B

2. Python is a...
(A) Snake  (B) Language  (C) Both  (D) None
Ans: C
```

*Tip:* Each question needs at least 2 options and an answer key.
""".strip()

ABOUT_TEXT = f"""
ℹ️ *About {BOT_NAME}*

*Version:* `{BOT_VERSION}`

*What this bot does:*
Converts MCQ text into beautiful, fully interactive HTML mock tests modelled after the Testbook exam interface.

*Features include:*
• Question palette navigation
• Live countdown timer
• Negative marking calculation
• Instant score & analysis
• Dark mode & mobile responsive

*Built with:* Python 3.12 · python-telegram-bot · SQLite

*Developer:* {OWNER_USERNAME}
""".strip()


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /start command."""
    user = update.effective_user
    upsert_user(user.id, user.username, user.first_name, user.last_name or "")
    logger.info("User %s started the bot", user.id)

    await update.message.reply_text(
        WELCOME_TEXT.format(bot_name=BOT_NAME),
        parse_mode="Markdown",
        reply_markup=main_menu_keyboard(),
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /help command."""
    await update.message.reply_text(
        HELP_TEXT, parse_mode="Markdown",
        reply_markup=back_to_menu_keyboard(),
    )


async def about_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /about command."""
    await update.message.reply_text(
        ABOUT_TEXT, parse_mode="Markdown",
        reply_markup=back_to_menu_keyboard(),
    )


# ── Callback handlers for main menu buttons ───────────────

async def menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Route main menu inline button taps."""
    query = update.callback_query
    await query.answer()
    data = query.data

    if data == "help":
        await query.edit_message_text(HELP_TEXT, parse_mode="Markdown",
                                      reply_markup=back_to_menu_keyboard())
    elif data == "about":
        await query.edit_message_text(ABOUT_TEXT, parse_mode="Markdown",
                                      reply_markup=back_to_menu_keyboard())
    elif data == "channel":
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("📢 Join Channel", url=CHANNEL_LINK),
            InlineKeyboardButton("🏠 Menu", callback_data="main_menu"),
        ]])
        await query.edit_message_text("📢 *Join our channel* for updates and tips!",
                                      parse_mode="Markdown", reply_markup=kb)
    elif data == "support":
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("🛠 Contact Support", url=SUPPORT_LINK),
            InlineKeyboardButton("🏠 Menu", callback_data="main_menu"),
        ]])
        await query.edit_message_text("🛠 *Need help?* Contact our support team.",
                                      parse_mode="Markdown", reply_markup=kb)
    elif data == "owner":
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        kb = InlineKeyboardMarkup([[
            InlineKeyboardButton("👤 Message Owner", url=f"https://t.me/{OWNER_USERNAME.lstrip('@')}"),
            InlineKeyboardButton("🏠 Menu", callback_data="main_menu"),
        ]])
        await query.edit_message_text(f"👤 *Owner:* {OWNER_USERNAME}",
                                      parse_mode="Markdown", reply_markup=kb)
    elif data == "main_menu":
        await query.edit_message_text(
            WELCOME_TEXT.format(bot_name=BOT_NAME),
            parse_mode="Markdown",
            reply_markup=main_menu_keyboard(),
        )
