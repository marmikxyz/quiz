"""
handlers/create_test.py
ConversationHandler that drives the full test-creation workflow:
  1. Collect text / .txt files (multi-message)
  2. Ask config questions one by one
  3. Generate HTML and send back
"""

import io
import json
import logging
import time
from pathlib import Path

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    ContextTypes,
    ConversationHandler,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    filters,
)

from config import (
    STATE_COLLECTING_TEXT, STATE_ASK_TIME, STATE_ASK_NEGATIVE,
    STATE_ASK_PASSING, STATE_ASK_TITLE, STATE_ASK_SUBJECT,
    STATE_ASK_INSTRUCTIONS, STATE_ASK_SHUFFLE, STATE_ASK_SHOW_RESULT,
    STATE_ASK_DARK_MODE, STATE_GENERATING,
    MAX_TEXT_ACCUMULATE_CHARS, MAX_FILE_SIZE_BYTES,
)
from database import save_test
from services import generate_html, save_html_file, TestConfig
from utils.keyboards import (
    cancel_keyboard, done_cancel_keyboard,
    negative_marking_keyboard, yes_no_keyboard, back_to_menu_keyboard,
)
from utils.parser import parse_questions

logger = logging.getLogger(__name__)

# Context data keys
_KEY_TEXT     = "raw_text_chunks"
_KEY_CFG      = "test_config"
_KEY_QUESTIONS = "parsed_questions"


# ─────────────────────────────────────────────
# Entry points
# ─────────────────────────────────────────────

async def create_test_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Entry via /create command."""
    context.user_data.clear()
    context.user_data[_KEY_TEXT] = []
    await update.message.reply_text(
        "📝 *Create a New Mock Test*\n\n"
        "Send your MCQ text now.\n"
        "You can send *multiple messages* — I'll collect them all.\n\n"
        "You can also *upload a .txt file* 📄\n\n"
        "When you're done, send /done or press the button below.",
        parse_mode="Markdown",
        reply_markup=done_cancel_keyboard(),
    )
    return STATE_COLLECTING_TEXT


async def create_test_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Entry via inline button 'Create Test'."""
    query = update.callback_query
    await query.answer()
    context.user_data.clear()
    context.user_data[_KEY_TEXT] = []
    await query.edit_message_text(
        "📝 *Create a New Mock Test*\n\n"
        "Send your MCQ text now.\n"
        "You can send *multiple messages* — I'll collect them all.\n\n"
        "You can also *upload a .txt file* 📄\n\n"
        "When you're done, send /done or press the button below.",
        parse_mode="Markdown",
        reply_markup=done_cancel_keyboard(),
    )
    return STATE_COLLECTING_TEXT


# ─────────────────────────────────────────────
# Text collection
# ─────────────────────────────────────────────

async def collect_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Accumulate plain-text messages."""
    chunks: list = context.user_data.setdefault(_KEY_TEXT, [])
    text = update.message.text or ""

    total = sum(len(c) for c in chunks)
    if total + len(text) > MAX_TEXT_ACCUMULATE_CHARS:
        await update.message.reply_text(
            "⚠️ Text limit reached (500 KB). Send /done to proceed with what you've sent.",
            reply_markup=done_cancel_keyboard(),
        )
        return STATE_COLLECTING_TEXT

    chunks.append(text)
    count = len(chunks)
    await update.message.reply_text(
        f"✅ Chunk {count} received ({len(text):,} chars). Keep sending or /done to continue.",
        reply_markup=done_cancel_keyboard(),
    )
    return STATE_COLLECTING_TEXT


async def collect_file(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle uploaded .txt file."""
    doc = update.message.document
    if not doc:
        await update.message.reply_text("Please send a .txt file.", reply_markup=done_cancel_keyboard())
        return STATE_COLLECTING_TEXT

    if not doc.file_name.lower().endswith(".txt"):
        await update.message.reply_text(
            "⚠️ Only .txt files are supported.", reply_markup=done_cancel_keyboard()
        )
        return STATE_COLLECTING_TEXT

    if doc.file_size > MAX_FILE_SIZE_BYTES:
        await update.message.reply_text(
            "⚠️ File too large (max 5 MB).", reply_markup=done_cancel_keyboard()
        )
        return STATE_COLLECTING_TEXT

    tg_file = await doc.get_file()
    buf = io.BytesIO()
    await tg_file.download_to_memory(buf)
    raw = buf.getvalue()

    # Try to decode
    for enc in ("utf-8", "utf-8-sig", "latin-1", "cp1252"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        await update.message.reply_text(
            "⚠️ Could not decode the file. Please ensure it is plain text (UTF-8).",
            reply_markup=done_cancel_keyboard(),
        )
        return STATE_COLLECTING_TEXT

    chunks: list = context.user_data.setdefault(_KEY_TEXT, [])
    chunks.append(text)
    await update.message.reply_text(
        f"📄 File received: `{doc.file_name}` ({len(text):,} chars).\nSend more or /done to proceed.",
        parse_mode="Markdown",
        reply_markup=done_cancel_keyboard(),
    )
    return STATE_COLLECTING_TEXT


async def done_input_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Inline button 'Done' triggers same path as /done command."""
    query = update.callback_query
    await query.answer()
    # Simulate /done by re-using the command handler logic
    chunks: list = context.user_data.get(_KEY_TEXT, [])
    if not chunks:
        await query.edit_message_text(
            "⚠️ You haven't sent any text yet! Please send text or a .txt file first.",
            reply_markup=done_cancel_keyboard(),
        )
        return STATE_COLLECTING_TEXT
    await query.edit_message_text("⏳ Processing your text…")
    return await _proceed_to_config(update, context, via_callback=True)


async def done_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle /done command."""
    chunks: list = context.user_data.get(_KEY_TEXT, [])
    if not chunks:
        await update.message.reply_text(
            "⚠️ No text collected yet! Please paste your MCQ text or upload a .txt file.",
            reply_markup=done_cancel_keyboard(),
        )
        return STATE_COLLECTING_TEXT
    await update.message.reply_text("⏳ Processing your text…")
    return await _proceed_to_config(update, context, via_callback=False)


async def _proceed_to_config(update: Update, context: ContextTypes.DEFAULT_TYPE,
                              via_callback: bool = False) -> int:
    """Parse questions and kick off config questions."""
    raw = "\n\n".join(context.user_data.get(_KEY_TEXT, []))
    questions = parse_questions(raw)

    if not questions:
        msg = (
            "❌ *No questions found!*\n\n"
            "I couldn't parse any MCQ questions from your text.\n\n"
            "*Supported format:*\n"
            "```\n1. Question text?\nA) Opt1  B) Opt2  C) Opt3  D) Opt4\nAnswer: A\n```\n\n"
            "Please resend your text or /cancel to abort."
        )
        if via_callback:
            await update.callback_query.message.reply_text(msg, parse_mode="Markdown",
                                                            reply_markup=cancel_keyboard())
        else:
            await update.message.reply_text(msg, parse_mode="Markdown",
                                            reply_markup=cancel_keyboard())
        context.user_data[_KEY_TEXT] = []
        return STATE_COLLECTING_TEXT

    context.user_data[_KEY_QUESTIONS] = questions
    context.user_data[_KEY_CFG] = {}

    text = f"✅ Found *{len(questions)} questions*!\n\nNow let's configure your test.\n\n⏱ *How long should the test be?*\n\nSend the number of minutes (e.g. `60`):"
    if via_callback:
        await update.callback_query.message.reply_text(text, parse_mode="Markdown",
                                                        reply_markup=cancel_keyboard())
    else:
        await update.message.reply_text(text, parse_mode="Markdown",
                                        reply_markup=cancel_keyboard())
    return STATE_ASK_TIME


# ─────────────────────────────────────────────
# Configuration Q&A
# ─────────────────────────────────────────────

async def ask_time_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Parse total-time input."""
    text = (update.message.text or "").strip()
    try:
        minutes = int(text)
        if minutes < 1 or minutes > 360:
            raise ValueError
    except ValueError:
        await update.message.reply_text(
            "⚠️ Please enter a valid number of minutes (1–360).",
            reply_markup=cancel_keyboard(),
        )
        return STATE_ASK_TIME

    context.user_data[_KEY_CFG]["total_time_minutes"] = minutes
    await update.message.reply_text(
        f"⏱ Time set to *{minutes} minutes*.\n\n➖ *Negative Marking?*",
        parse_mode="Markdown",
        reply_markup=negative_marking_keyboard(),
    )
    return STATE_ASK_NEGATIVE


async def ask_negative_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    neg = float(query.data.split("_")[1])
    context.user_data[_KEY_CFG]["negative_marking"] = neg

    label = f"-{neg}" if neg else "No negative marking"
    await query.edit_message_text(
        f"➖ Negative marking: *{label}*\n\n🎯 *Passing Marks?*\nSend the minimum marks required to pass (e.g. `35`):",
        parse_mode="Markdown",
        reply_markup=cancel_keyboard(),
    )
    return STATE_ASK_PASSING


async def ask_passing_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    text = (update.message.text or "").strip()
    questions = context.user_data.get(_KEY_QUESTIONS, [])
    total = len(questions)
    try:
        passing = int(text)
        if passing < 0 or passing > total:
            raise ValueError
    except ValueError:
        await update.message.reply_text(
            f"⚠️ Enter a valid number between 0 and {total}.",
            reply_markup=cancel_keyboard(),
        )
        return STATE_ASK_PASSING

    context.user_data[_KEY_CFG]["passing_marks"] = passing
    await update.message.reply_text(
        f"🎯 Passing marks: *{passing}*\n\n📌 *Exam Title?*\nSend the title for your test:",
        parse_mode="Markdown",
        reply_markup=cancel_keyboard(),
    )
    return STATE_ASK_TITLE


async def ask_title_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    title = (update.message.text or "").strip()[:120]
    if not title:
        await update.message.reply_text("⚠️ Title cannot be empty.", reply_markup=cancel_keyboard())
        return STATE_ASK_TITLE

    context.user_data[_KEY_CFG]["title"] = title
    await update.message.reply_text(
        f"📌 Title: *{title}*\n\n📚 *Subject Name?*\nSend the subject (e.g. `Mathematics`, `GK`):",
        parse_mode="Markdown",
        reply_markup=cancel_keyboard(),
    )
    return STATE_ASK_SUBJECT


async def ask_subject_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    subject = (update.message.text or "").strip()[:80] or "General"
    context.user_data[_KEY_CFG]["subject"] = subject
    await update.message.reply_text(
        f"📚 Subject: *{subject}*\n\n📋 *Show Instructions Page?*",
        parse_mode="Markdown",
        reply_markup=yes_no_keyboard("instr_yes", "instr_no"),
    )
    return STATE_ASK_INSTRUCTIONS


async def ask_instructions_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    show = query.data == "instr_yes"
    context.user_data[_KEY_CFG]["show_instructions"] = show
    await query.edit_message_text(
        f"📋 Instructions page: *{'Yes' if show else 'No'}*\n\n🔀 *Shuffle Questions?*",
        parse_mode="Markdown",
        reply_markup=yes_no_keyboard("shuffle_yes", "shuffle_no"),
    )
    return STATE_ASK_SHUFFLE


async def ask_shuffle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    shuffle = query.data == "shuffle_yes"
    context.user_data[_KEY_CFG]["shuffle_questions"] = shuffle
    await query.edit_message_text(
        f"🔀 Shuffle: *{'Yes' if shuffle else 'No'}*\n\n📊 *Show Result Immediately After Submit?*",
        parse_mode="Markdown",
        reply_markup=yes_no_keyboard("result_yes", "result_no"),
    )
    return STATE_ASK_SHOW_RESULT


async def ask_show_result_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    show_result = query.data == "result_yes"
    context.user_data[_KEY_CFG]["show_result_immediately"] = show_result
    await query.edit_message_text(
        f"📊 Show result immediately: *{'Yes' if show_result else 'No'}*\n\n🌙 *Enable Dark Mode by Default?*",
        parse_mode="Markdown",
        reply_markup=yes_no_keyboard("dark_yes", "dark_no"),
    )
    return STATE_ASK_DARK_MODE


async def ask_dark_mode_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    dark = query.data == "dark_yes"
    context.user_data[_KEY_CFG]["dark_mode"] = dark
    await query.edit_message_text(
        f"🌙 Dark mode: *{'Yes' if dark else 'No'}*\n\n⚙️ All settings collected! Generating your test…",
        parse_mode="Markdown",
    )
    return await _generate_and_send(update, context)


# ─────────────────────────────────────────────
# Generation
# ─────────────────────────────────────────────

async def _generate_and_send(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Build HTML, save, and send to user."""
    cfg_data = context.user_data.get(_KEY_CFG, {})
    questions = context.user_data.get(_KEY_QUESTIONS, [])
    user = update.effective_user

    config = TestConfig(
        title=cfg_data.get("title", "Mock Test"),
        subject=cfg_data.get("subject", "General"),
        total_time_minutes=cfg_data.get("total_time_minutes", 60),
        negative_marking=cfg_data.get("negative_marking", 0.0),
        passing_marks=cfg_data.get("passing_marks", 0),
        show_instructions=cfg_data.get("show_instructions", True),
        shuffle_questions=cfg_data.get("shuffle_questions", False),
        show_result_immediately=cfg_data.get("show_result_immediately", True),
        dark_mode=cfg_data.get("dark_mode", False),
    )

    try:
        html = generate_html(questions, config)
        # Temporary ID for filename before DB save
        temp_id = int(time.time())
        html_path = save_html_file(html, user.id, temp_id, config.title)

        # Persist to DB
        test_id = save_test(
            user_id=user.id,
            title=config.title,
            subject=config.subject,
            filename=html_path.name,
            question_count=len(questions),
            config_json=json.dumps(cfg_data),
        )

        caption = (
            f"✅ *Your Mock Test is Ready!*\n\n"
            f"📌 *Title:* {config.title}\n"
            f"📚 *Subject:* {config.subject}\n"
            f"❓ *Questions:* {len(questions)}\n"
            f"⏱ *Duration:* {config.total_time_minutes} minutes\n"
            f"➖ *Negative:* {f'-{config.negative_marking}' if config.negative_marking else 'None'}\n"
            f"🎯 *Passing Marks:* {config.passing_marks}\n\n"
            f"📥 Open the HTML file in any browser to take the test!"
        )

        chat_id = update.effective_chat.id
        with open(html_path, "rb") as f:
            await context.bot.send_document(
                chat_id=chat_id,
                document=f,
                filename=html_path.name,
                caption=caption,
                parse_mode="Markdown",
                reply_markup=back_to_menu_keyboard(),
            )

        logger.info("Test %d sent to user %d (%d questions)", test_id, user.id, len(questions))

    except Exception as exc:
        logger.exception("Error generating test for user %d: %s", user.id, exc)
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="❌ An error occurred while generating your test. Please try again.\n\n/create",
            reply_markup=back_to_menu_keyboard(),
        )

    context.user_data.clear()
    return ConversationHandler.END


# ─────────────────────────────────────────────
# Cancel
# ─────────────────────────────────────────────

async def cancel_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.clear()
    text = "❌ Operation cancelled. Use /start to return to the main menu."
    if update.message:
        await update.message.reply_text(text, reply_markup=back_to_menu_keyboard())
    else:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(text, reply_markup=back_to_menu_keyboard())
    return ConversationHandler.END


async def cancel_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Inline 'Cancel' button."""
    return await cancel_command(update, context)


# ─────────────────────────────────────────────
# ConversationHandler factory
# ─────────────────────────────────────────────

def build_conversation_handler() -> ConversationHandler:
    return ConversationHandler(
        entry_points=[
            CommandHandler("create", create_test_command),
            CallbackQueryHandler(create_test_callback, pattern="^create_test$"),
        ],
        states={
            STATE_COLLECTING_TEXT: [
                CommandHandler("done", done_command),
                CommandHandler("cancel", cancel_command),
                CallbackQueryHandler(done_input_callback, pattern="^done_input$"),
                CallbackQueryHandler(cancel_callback, pattern="^cancel$"),
                MessageHandler(filters.Document.MimeType("text/plain"), collect_file),
                MessageHandler(filters.TEXT & ~filters.COMMAND, collect_text),
            ],
            STATE_ASK_TIME: [
                CommandHandler("cancel", cancel_command),
                CallbackQueryHandler(cancel_callback, pattern="^cancel$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, ask_time_message),
            ],
            STATE_ASK_NEGATIVE: [
                CommandHandler("cancel", cancel_command),
                CallbackQueryHandler(cancel_callback, pattern="^cancel$"),
                CallbackQueryHandler(ask_negative_callback, pattern="^neg_"),
            ],
            STATE_ASK_PASSING: [
                CommandHandler("cancel", cancel_command),
                CallbackQueryHandler(cancel_callback, pattern="^cancel$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, ask_passing_message),
            ],
            STATE_ASK_TITLE: [
                CommandHandler("cancel", cancel_command),
                CallbackQueryHandler(cancel_callback, pattern="^cancel$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, ask_title_message),
            ],
            STATE_ASK_SUBJECT: [
                CommandHandler("cancel", cancel_command),
                CallbackQueryHandler(cancel_callback, pattern="^cancel$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, ask_subject_message),
            ],
            STATE_ASK_INSTRUCTIONS: [
                CommandHandler("cancel", cancel_command),
                CallbackQueryHandler(cancel_callback, pattern="^cancel$"),
                CallbackQueryHandler(ask_instructions_callback, pattern="^instr_"),
            ],
            STATE_ASK_SHUFFLE: [
                CommandHandler("cancel", cancel_command),
                CallbackQueryHandler(cancel_callback, pattern="^cancel$"),
                CallbackQueryHandler(ask_shuffle_callback, pattern="^shuffle_"),
            ],
            STATE_ASK_SHOW_RESULT: [
                CommandHandler("cancel", cancel_command),
                CallbackQueryHandler(cancel_callback, pattern="^cancel$"),
                CallbackQueryHandler(ask_show_result_callback, pattern="^result_"),
            ],
            STATE_ASK_DARK_MODE: [
                CommandHandler("cancel", cancel_command),
                CallbackQueryHandler(cancel_callback, pattern="^cancel$"),
                CallbackQueryHandler(ask_dark_mode_callback, pattern="^dark_"),
            ],
        },
        fallbacks=[
            CommandHandler("cancel", cancel_command),
            CommandHandler("start", cancel_command),
        ],
        allow_reentry=True,
        name="create_test_conv",
        persistent=False,
    )
