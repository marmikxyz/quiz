"""
handlers/my_tests.py - Shows the user's previously generated tests.
"""

import logging
from telegram import Update
from telegram.ext import ContextTypes

from database import get_user_tests
from utils.keyboards import back_to_menu_keyboard

logger = logging.getLogger(__name__)


async def my_tests_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()

    user_id = update.effective_user.id
    tests = get_user_tests(user_id)

    if not tests:
        await query.edit_message_text(
            "📂 *My Tests*\n\nYou haven't created any tests yet.\nClick *Create Test* to get started!",
            parse_mode="Markdown",
            reply_markup=back_to_menu_keyboard(),
        )
        return

    lines = ["📂 *My Recent Tests* (last 20)\n"]
    for t in tests:
        date = t["created_at"][:10]
        lines.append(
            f"• *{t['title']}* — {t['subject'] or 'N/A'}\n"
            f"  📅 {date}  |  ❓ {t['question_count']} questions"
        )

    await query.edit_message_text(
        "\n\n".join(lines),
        parse_mode="Markdown",
        reply_markup=back_to_menu_keyboard(),
    )
