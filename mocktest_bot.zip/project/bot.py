"""
bot.py - Application entry point.

Supports two run modes:
  • Webhook  – when WEBHOOK_URL env var is set (recommended for Railway)
  • Polling  – fallback for local development
"""

import logging
import sys
from pathlib import Path

from telegram import BotCommand
from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
)

# ── Bootstrap path so sub-packages resolve correctly ──────
sys.path.insert(0, str(Path(__file__).parent))

from config import (
    BOT_TOKEN, WEBHOOK_URL, PORT, LOG_LEVEL,
    BOT_NAME,
)
from database import init_db
from handlers import (
    start_command, help_command, about_command, menu_callback,
    my_tests_callback, build_conversation_handler,
)

# ── Logging ───────────────────────────────────────────────
logging.basicConfig(
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    level=getattr(logging, LOG_LEVEL.upper(), logging.INFO),
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# Build Application
# ─────────────────────────────────────────────

def build_app() -> Application:
    app = Application.builder().token(BOT_TOKEN).build()

    # ── ConversationHandler (must be first to capture /create) ──
    app.add_handler(build_conversation_handler())

    # ── Simple commands ──
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("about", about_command))

    # ── Inline button callbacks ──
    app.add_handler(CallbackQueryHandler(my_tests_callback, pattern="^my_tests$"))
    app.add_handler(CallbackQueryHandler(menu_callback, pattern="^(help|about|channel|support|owner|main_menu)$"))

    return app


# ─────────────────────────────────────────────
# Bot Commands menu (shown in Telegram UI)
# ─────────────────────────────────────────────

async def set_commands(app: Application) -> None:
    commands = [
        BotCommand("start",  "Main menu"),
        BotCommand("create", "Create a new mock test"),
        BotCommand("help",   "How to use the bot"),
        BotCommand("about",  "About MockTest Pro"),
        BotCommand("cancel", "Cancel current operation"),
        BotCommand("done",   "Finish sending text"),
    ]
    await app.bot.set_my_commands(commands)
    logger.info("Bot commands registered")


# ─────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────

def main() -> None:
    logger.info("Starting %s…", BOT_NAME)

    # Initialise database
    init_db()

    app = build_app()

    if WEBHOOK_URL:
        # ── Webhook mode (Railway / production) ──────────────
        webhook_path = f"/webhook/{BOT_TOKEN}"
        full_url = f"{WEBHOOK_URL.rstrip('/')}{webhook_path}"
        logger.info("Webhook mode: %s  port=%d", full_url, PORT)

        app.run_webhook(
            listen="0.0.0.0",
            port=PORT,
            url_path=webhook_path,
            webhook_url=full_url,
            drop_pending_updates=True,
            close_loop=False,
        )
    else:
        # ── Polling mode (local development) ─────────────────
        logger.info("Polling mode (no WEBHOOK_URL set)")
        app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
