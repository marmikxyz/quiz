# 🎯 MockTest Pro — Telegram Bot

Convert MCQ text into **interactive Testbook-style HTML mock tests** via Telegram.

---

## ✨ Features

| Feature | Detail |
|---|---|
| 📝 Input | Plain text (multi-message) or `.txt` file upload |
| ⚙️ Config | Timer, negative marking, passing marks, title, subject |
| 🔀 Shuffle | Optional question randomisation |
| 🌙 Dark mode | Toggle default dark/light theme |
| 📊 Result | Instant score, accuracy, per-question analysis |
| 💾 History | SQLite stores all generated tests per user |
| 🚀 Deploy | Webhook-based, Railway-ready |

---

## 📁 Project Structure

```
project/
├── bot.py                  # Entry point
├── config.py               # All settings via env vars
├── handlers/
│   ├── __init__.py
│   ├── start.py            # /start, /help, /about, menu callbacks
│   ├── my_tests.py         # "My Tests" button
│   └── create_test.py      # ConversationHandler (full create flow)
├── services/
│   ├── __init__.py
│   └── html_generator.py   # Generates the HTML mock test
├── database/
│   ├── __init__.py
│   └── db.py               # SQLite layer
├── utils/
│   ├── __init__.py
│   ├── parser.py           # MCQ text → Question objects
│   └── keyboards.py        # InlineKeyboardMarkup builders
├── generated_tests/        # Output HTML files (auto-created)
├── requirements.txt
├── Procfile
├── railway.json
├── Dockerfile
└── README.md
```

---

## 🤖 Bot Commands

| Command | Description |
|---|---|
| `/start` | Show main menu |
| `/create` | Start creating a test |
| `/done` | Finish sending text, proceed to config |
| `/cancel` | Cancel current operation |
| `/help` | Usage guide |
| `/about` | Bot info |

---

## 📝 Supported Question Format

The parser handles several common MCQ formats:

**Format A — Numbered with lettered options:**
```
1. What is the capital of India?
A) Mumbai  B) Delhi  C) Kolkata  D) Chennai
Answer: B

2. Python is interpreted at...
A) Compile time  B) Runtime  C) Link time  D) Never
Answer: B
```

**Format B — Q: prefix:**
```
Q: Who invented the telephone?
a. Edison
b. Bell
c. Tesla
d. Marconi
Ans: b
```

**Format C — Block separated by blank lines:**
```
What is 2 + 2?
(A) 3  (B) 4  (C) 5  (D) 6
Answer: B
```

---

## 🚀 Railway Deployment (Recommended)

### Step 1 — Create a Telegram Bot

1. Open [@BotFather](https://t.me/BotFather) in Telegram
2. Send `/newbot` and follow the prompts
3. Copy your **Bot Token**

### Step 2 — Deploy to Railway

1. **Fork / push** this project to a GitHub repository

2. Go to [railway.app](https://railway.app) → **New Project** → **Deploy from GitHub**

3. Select your repository

4. Railway auto-detects the `Dockerfile` and builds it

### Step 3 — Set Environment Variables

In Railway → your service → **Variables** tab, add:

| Variable | Value | Required |
|---|---|---|
| `BOT_TOKEN` | Your token from BotFather | ✅ |
| `WEBHOOK_URL` | `https://your-app.up.railway.app` | ✅ |
| `CHANNEL_LINK` | `https://t.me/yourchannel` | Optional |
| `SUPPORT_LINK` | `https://t.me/yoursupport` | Optional |
| `OWNER_USERNAME` | `@yourhandle` | Optional |
| `LOG_LEVEL` | `INFO` | Optional |

> **How to find WEBHOOK_URL:**  
> Railway → your service → **Settings** → copy the auto-generated domain,  
> e.g. `https://mocktest-bot-production.up.railway.app`

### Step 4 — Deploy

Railway auto-deploys on every push. After the first deploy you should see:

```
Starting MockTest Pro…
Database initialised at /app/database/bot.db
Webhook mode: https://your-app.up.railway.app/webhook/<token>  port=8443
```

### Step 5 — Test

Open Telegram, find your bot, send `/start`. 🎉

---

## 💻 Local Development

```bash
# Clone & enter
git clone https://github.com/yourname/mocktest-bot
cd mocktest-bot

# Create venv
python3.12 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate

# Install
pip install -r requirements.txt

# Set env (no WEBHOOK_URL → polling mode)
export BOT_TOKEN="your_token_here"

# Run
python bot.py
```

---

## 🏗 HTML Test Features

The generated HTML file is fully self-contained (no internet required after generation):

- **Question Palette** — colour-coded navigation grid
- **Timer** — countdown with red flash warning at 5 minutes
- **Save & Next** — saves answer and advances
- **Mark for Review** — orange flag for uncertain questions
- **Clear Response** — deselect current answer
- **Submit Confirmation** — modal with attempt summary before final submit
- **Result Page** — score, accuracy, pass/fail badge, per-question analysis table
- **Dark Mode** — configured at generation time, toggleable via `data-theme`
- **Fullscreen** — one-click fullscreen button in header
- **Mobile Responsive** — palette hidden on mobile, accessible via hamburger

---

## 🔒 Security Notes

- Bot token is read from env variables — never hardcoded
- Docker container runs as a non-root user
- SQLite WAL mode for concurrent read safety
- File size limited to 5 MB for uploads

---

## 📜 License

MIT — free to use and modify.
