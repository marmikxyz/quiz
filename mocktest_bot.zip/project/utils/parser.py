"""
utils/parser.py - Parses raw text into a structured list of MCQ questions.

Supported formats
─────────────────
Format A  (numbered, lettered options)
    1. What is 2+2?
    A) 3   B) 4   C) 5   D) 6
    Answer: B

Format B  (Q: / Options block / Ans:)
    Q: Capital of India?
    a. Mumbai
    b. Delhi
    c. Kolkata
    d. Chennai
    Ans: b

Format C  (blank-line separated, answer on last line)
    What is Python?
    (A) Snake    (B) Language    (C) Both    (D) None
    Answer: C

The parser tries all formats in order and returns whichever gives the most questions.
"""

import re
import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class Question:
    number: int
    text: str
    options: list[str] = field(default_factory=list)   # list of 4 option texts (without labels)
    correct: int = 0                                    # 0-based index of correct option


# ─────────────────────────────────────────────
# Internal regex patterns
# ─────────────────────────────────────────────

_ANS_MAP = {
    "a": 0, "b": 1, "c": 2, "d": 3,
    "1": 0, "2": 1, "3": 2, "4": 3,
}

_OPT_PATTERN = re.compile(
    r"""
    (?:^|\s)                        # start or whitespace
    (?:\(?)                         # optional opening paren
    ([a-dA-D1-4])                   # option label
    (?:\)|\.|\s*[\-:])              # closing paren / dot / dash / colon
    \s*                             # optional space
    (.+?)                           # option text (non-greedy)
    (?=\s*(?:\(?[a-dA-D1-4](?:\)|\.|\s*[\-:]))|$)  # lookahead: next option or EOL
    """,
    re.VERBOSE | re.DOTALL,
)

_ANS_PATTERN = re.compile(
    r"""
    (?:answer|ans|correct|key)      # keyword
    \s*[:\-]?\s*                    # separator
    (?:\(?)                         # optional paren
    ([a-dA-D1-4])                   # answer label
    (?:\))?                         # optional paren
    """,
    re.IGNORECASE | re.VERBOSE,
)

_Q_START = re.compile(r"^(?:Q\.?\s*)?(\d+)[.)]\s*(.+)", re.IGNORECASE)


# ─────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────

def parse_questions(raw_text: str) -> list[Question]:
    """
    Parse *raw_text* and return a list of Question objects.
    Falls back to an empty list if nothing recognisable is found.
    """
    # Normalise line endings
    text = raw_text.replace("\r\n", "\n").replace("\r", "\n")

    candidates = [
        _parse_numbered(text),
        _parse_block(text),
    ]
    best = max(candidates, key=len)
    logger.info("Parsed %d questions from raw text (%d chars)", len(best), len(text))
    return best


# ─────────────────────────────────────────────
# Strategy A – numbered questions
# ─────────────────────────────────────────────

def _parse_numbered(text: str) -> list[Question]:
    """Parse questions that start with '1.' or '1)' style numbering."""
    questions: list[Question] = []
    lines = text.split("\n")
    i = 0
    q_num = 0

    while i < len(lines):
        m = _Q_START.match(lines[i].strip())
        if m:
            q_num += 1
            q_text = m.group(2).strip()
            # Accumulate question text across multiple lines until options found
            j = i + 1
            option_block_lines: list[str] = []
            while j < len(lines):
                stripped = lines[j].strip()
                if _Q_START.match(stripped):
                    break
                option_block_lines.append(stripped)
                j += 1

            option_block = " ".join(option_block_lines)
            opts, ans = _extract_options_and_answer(option_block)

            if len(opts) >= 2:
                questions.append(Question(
                    number=q_num,
                    text=q_text,
                    options=opts,
                    correct=ans,
                ))
            i = j
        else:
            i += 1

    return questions


# ─────────────────────────────────────────────
# Strategy B – blank-line separated blocks
# ─────────────────────────────────────────────

def _parse_block(text: str) -> list[Question]:
    """Parse questions separated by blank lines."""
    questions: list[Question] = []
    blocks = re.split(r"\n{2,}", text.strip())
    q_num = 0

    for block in blocks:
        block = block.strip()
        if not block:
            continue

        lines = [ln.strip() for ln in block.split("\n") if ln.strip()]
        if len(lines) < 3:
            continue

        # First line (or lines before options) = question text
        # Find where options start
        opt_start = None
        for idx, ln in enumerate(lines):
            if re.match(r"^(?:\(?)[a-dA-D1-4](?:\)|\.|\s*[\-:])\s*\S", ln):
                opt_start = idx
                break

        if opt_start is None or opt_start == 0:
            continue

        q_text = " ".join(lines[:opt_start])
        option_block = " ".join(lines[opt_start:])
        opts, ans = _extract_options_and_answer(option_block)

        if len(opts) >= 2:
            q_num += 1
            questions.append(Question(
                number=q_num,
                text=q_text,
                options=opts,
                correct=ans,
            ))

    return questions


# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────

def _extract_options_and_answer(block: str) -> tuple[list[str], int]:
    """Return (list_of_option_texts, correct_index_0based) from a mixed block."""
    # Strip answer first
    ans_match = _ANS_PATTERN.search(block)
    correct = 0
    if ans_match:
        correct = _ANS_MAP.get(ans_match.group(1).lower(), 0)
        block = block[: ans_match.start()].strip()

    # Extract options
    opts: list[str] = []
    seen_labels: set[str] = set()

    for m in _OPT_PATTERN.finditer(" " + block):
        label = m.group(1).lower()
        if label in seen_labels:
            continue
        seen_labels.add(label)
        opts.append(m.group(2).strip())

    # Normalise to 4 options (pad or truncate)
    while len(opts) < 4:
        opts.append(f"Option {len(opts) + 1}")
    opts = opts[:4]

    return opts, correct
