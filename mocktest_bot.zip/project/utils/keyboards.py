"""
utils/keyboards.py - All InlineKeyboardMarkup builders in one place.
"""

from telegram import InlineKeyboardButton, InlineKeyboardMarkup


def main_menu_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📝 Create Test", callback_data="create_test"),
            InlineKeyboardButton("❓ Help", callback_data="help"),
        ],
        [
            InlineKeyboardButton("📂 My Tests", callback_data="my_tests"),
            InlineKeyboardButton("📢 Channel", callback_data="channel"),
        ],
        [
            InlineKeyboardButton("🛠 Support", callback_data="support"),
            InlineKeyboardButton("👤 Owner", callback_data="owner"),
        ],
        [
            InlineKeyboardButton("ℹ️ About", callback_data="about"),
        ],
    ])


def cancel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("❌ Cancel", callback_data="cancel"),
    ]])


def done_cancel_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("✅ Done (/done)", callback_data="done_input"),
        InlineKeyboardButton("❌ Cancel", callback_data="cancel"),
    ]])


def negative_marking_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🚫 No Negative", callback_data="neg_0"),
            InlineKeyboardButton("-0.25", callback_data="neg_0.25"),
        ],
        [
            InlineKeyboardButton("-0.50", callback_data="neg_0.50"),
            InlineKeyboardButton("-1.00", callback_data="neg_1.00"),
        ],
    ])


def yes_no_keyboard(yes_data: str, no_data: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("✅ Yes", callback_data=yes_data),
        InlineKeyboardButton("❌ No", callback_data=no_data),
    ]])


def back_to_menu_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu"),
    ]])
