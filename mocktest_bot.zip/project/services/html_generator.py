"""
services/html_generator.py
Generates a fully self-contained, responsive HTML mock test
modelled after Testbook's exam interface.
"""

import json
import random
import logging
from pathlib import Path
from dataclasses import dataclass

from utils.parser import Question

logger = logging.getLogger(__name__)


@dataclass
class TestConfig:
    title: str = "Mock Test"
    subject: str = "General"
    total_time_minutes: int = 60
    negative_marking: float = 0.0
    passing_marks: int = 0
    show_instructions: bool = True
    shuffle_questions: bool = False
    show_result_immediately: bool = True
    dark_mode: bool = False


def generate_html(questions: list[Question], config: TestConfig) -> str:
    """Return complete HTML string for the mock test."""

    if config.shuffle_questions:
        questions = list(questions)
        random.shuffle(questions)
        for i, q in enumerate(questions):
            q.number = i + 1

    questions_json = json.dumps([
        {
            "id": q.number,
            "text": q.text,
            "options": q.options,
            "correct": q.correct,
        }
        for q in questions
    ], ensure_ascii=False)

    config_json = json.dumps({
        "title": config.title,
        "subject": config.subject,
        "totalTimeSeconds": config.total_time_minutes * 60,
        "negativeMarking": config.negative_marking,
        "passingMarks": config.passing_marks,
        "showResultImmediately": config.show_result_immediately,
        "darkMode": config.dark_mode,
        "totalQuestions": len(questions),
        "marksPerQuestion": 1,
    })

    instructions_html = _build_instructions(config) if config.show_instructions else ""

    html = f"""<!DOCTYPE html>
<html lang="en" data-theme="{'dark' if config.dark_mode else 'light'}">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0"/>
<title>{config.title} – MockTest Pro</title>
<style>
/* ── CSS Variables ── */
:root {{
  --bg: #f0f2f5;
  --surface: #ffffff;
  --surface2: #f8f9fa;
  --border: #dee2e6;
  --text: #212529;
  --text2: #6c757d;
  --primary: #1a73e8;
  --primary-dark: #1557b0;
  --primary-light: #e8f0fe;
  --success: #28a745;
  --danger: #dc3545;
  --warning: #ffc107;
  --orange: #fd7e14;
  --shadow: 0 2px 8px rgba(0,0,0,.12);
  --radius: 8px;
  --header-h: 60px;
  --palette-w: 280px;
}}
[data-theme="dark"] {{
  --bg: #121212;
  --surface: #1e1e1e;
  --surface2: #2a2a2a;
  --border: #333;
  --text: #e0e0e0;
  --text2: #9e9e9e;
  --primary-light: #1c3461;
  --shadow: 0 2px 8px rgba(0,0,0,.4);
}}

/* ── Reset & Base ── */
*,*::before,*::after{{box-sizing:border-box;margin:0;padding:0}}
body{{font-family:'Segoe UI',system-ui,-apple-system,sans-serif;background:var(--bg);color:var(--text);min-height:100vh;overflow-x:hidden}}
button{{cursor:pointer;border:none;font-family:inherit}}
a{{color:var(--primary);text-decoration:none}}

/* ── Screens ── */
.screen{{display:none;min-height:100vh}}
.screen.active{{display:flex;flex-direction:column}}

/* ═══════════════════════════════════════════
   INSTRUCTIONS SCREEN
═══════════════════════════════════════════ */
#instructions-screen{{align-items:center;justify-content:center;padding:20px}}
.instr-card{{background:var(--surface);border-radius:12px;box-shadow:var(--shadow);max-width:700px;width:100%;overflow:hidden}}
.instr-header{{background:var(--primary);color:#fff;padding:24px 28px}}
.instr-header h1{{font-size:1.5rem;margin-bottom:4px}}
.instr-header p{{opacity:.85;font-size:.9rem}}
.instr-meta{{display:flex;gap:20px;flex-wrap:wrap;padding:16px 28px;background:var(--surface2);border-bottom:1px solid var(--border);font-size:.85rem;color:var(--text2)}}
.instr-meta span strong{{color:var(--text)}}
.instr-body{{padding:24px 28px}}
.instr-body h3{{font-size:1rem;margin-bottom:12px;color:var(--primary)}}
.instr-body ul{{padding-left:20px;line-height:1.9;font-size:.9rem}}
.legend{{display:flex;flex-wrap:wrap;gap:10px;margin:16px 0}}
.legend-item{{display:flex;align-items:center;gap:6px;font-size:.82rem}}
.legend-dot{{width:24px;height:24px;border-radius:4px;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:.75rem}}
.start-btn{{display:block;width:100%;margin-top:20px;padding:14px;background:var(--primary);color:#fff;border-radius:8px;font-size:1rem;font-weight:600;letter-spacing:.3px;transition:background .2s}}
.start-btn:hover{{background:var(--primary-dark)}}

/* ═══════════════════════════════════════════
   EXAM SCREEN
═══════════════════════════════════════════ */
#exam-screen{{flex-direction:column}}
/* Header */
.exam-header{{position:sticky;top:0;z-index:100;background:var(--primary);color:#fff;height:var(--header-h);display:flex;align-items:center;padding:0 16px;gap:12px;box-shadow:0 2px 6px rgba(0,0,0,.25)}}
.exam-title{{flex:1;font-size:1rem;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}
.timer-box{{display:flex;align-items:center;gap:6px;background:rgba(0,0,0,.25);padding:6px 12px;border-radius:6px;font-size:.9rem;font-weight:700;min-width:90px;justify-content:center}}
.timer-box.warning{{background:#e53935;animation:pulse 1s infinite}}
@keyframes pulse{{0%,100%{{opacity:1}}50%{{opacity:.7}}}}
.fullscreen-btn{{background:rgba(255,255,255,.15);border:none;color:#fff;padding:6px 10px;border-radius:6px;font-size:1rem}}

/* Layout */
.exam-body{{display:flex;flex:1;overflow:hidden;height:calc(100vh - var(--header-h))}}
.question-panel{{flex:1;overflow-y:auto;display:flex;flex-direction:column}}
.palette-panel{{width:var(--palette-w);border-left:1px solid var(--border);overflow-y:auto;background:var(--surface);flex-shrink:0}}

/* Question Area */
.q-area{{padding:20px;flex:1}}
.q-meta{{font-size:.8rem;color:var(--text2);margin-bottom:8px}}
.q-text{{font-size:1rem;line-height:1.7;margin-bottom:20px;color:var(--text)}}
.q-number-badge{{display:inline-block;background:var(--primary);color:#fff;border-radius:4px;padding:2px 8px;font-size:.8rem;margin-bottom:8px}}

/* Options */
.options-list{{display:flex;flex-direction:column;gap:10px}}
.option{{display:flex;align-items:flex-start;gap:12px;padding:12px 16px;border:2px solid var(--border);border-radius:8px;cursor:pointer;transition:all .15s;background:var(--surface)}}
.option:hover{{border-color:var(--primary);background:var(--primary-light)}}
.option.selected{{border-color:var(--primary);background:var(--primary-light)}}
.option-label{{min-width:28px;height:28px;border-radius:50%;background:var(--surface2);border:2px solid var(--border);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.8rem;flex-shrink:0;transition:all .15s}}
.option.selected .option-label{{background:var(--primary);border-color:var(--primary);color:#fff}}
.option-text{{font-size:.95rem;line-height:1.5;padding-top:2px}}

/* Action Row */
.q-actions{{padding:16px 20px;display:flex;flex-wrap:wrap;gap:8px;border-top:1px solid var(--border);background:var(--surface);position:sticky;bottom:0}}
.btn-action{{padding:9px 16px;border-radius:6px;font-size:.85rem;font-weight:600;transition:all .15s;border:none}}
.btn-save-next{{background:var(--primary);color:#fff}}
.btn-save-next:hover{{background:var(--primary-dark)}}
.btn-mark-review{{background:#9c27b0;color:#fff}}
.btn-mark-review:hover{{background:#7b1fa2}}
.btn-clear{{background:var(--surface2);color:var(--text);border:1px solid var(--border)}}
.btn-clear:hover{{background:var(--border)}}
.btn-prev,.btn-next{{background:var(--surface2);color:var(--primary);border:1px solid var(--primary);padding:9px 18px}}
.btn-prev:hover,.btn-next:hover{{background:var(--primary);color:#fff}}
.btn-submit-main{{background:var(--success);color:#fff;margin-left:auto}}
.btn-submit-main:hover{{background:#218838}}

/* Question Palette */
.palette-header{{padding:12px 16px;font-weight:700;font-size:.9rem;border-bottom:1px solid var(--border);background:var(--surface2)}}
.palette-legend{{padding:8px 12px;display:flex;flex-wrap:wrap;gap:6px;border-bottom:1px solid var(--border)}}
.pal-stat{{display:flex;align-items:center;gap:4px;font-size:.72rem;color:var(--text2)}}
.pal-dot{{width:16px;height:16px;border-radius:3px}}
.palette-grid{{display:grid;grid-template-columns:repeat(5,1fr);gap:6px;padding:12px}}
.pal-btn{{aspect-ratio:1;border-radius:5px;font-size:.78rem;font-weight:700;background:var(--surface2);color:var(--text);border:1px solid var(--border);transition:all .12s}}
.pal-btn.current{{outline:3px solid var(--primary);outline-offset:1px}}
.pal-btn.answered{{background:#4caf50;color:#fff;border-color:#4caf50}}
.pal-btn.review{{background:#9c27b0;color:#fff;border-color:#9c27b0}}
.pal-btn.answered-review{{background:#ff9800;color:#fff;border-color:#ff9800}}
.pal-btn.not-visited{{background:var(--surface2);color:var(--text2)}}
.palette-footer{{padding:12px;border-top:1px solid var(--border)}}
.btn-submit-pal{{width:100%;padding:10px;background:var(--success);color:#fff;border-radius:6px;font-weight:700;font-size:.9rem}}
.btn-submit-pal:hover{{background:#218838}}

/* Subject tabs */
.subject-tab{{padding:8px 16px;font-size:.85rem;font-weight:600;color:var(--text2);border-bottom:3px solid transparent;background:none;margin-right:4px}}
.subject-tab.active{{color:var(--primary);border-bottom-color:var(--primary)}}
.subject-tabs{{display:flex;overflow-x:auto;border-bottom:1px solid var(--border);background:var(--surface);padding:0 16px;position:sticky;top:var(--header-h);z-index:90}}

/* ═══════════════════════════════════════════
   SUBMIT MODAL
═══════════════════════════════════════════ */
.modal-overlay{{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:200;align-items:center;justify-content:center}}
.modal-overlay.open{{display:flex}}
.modal{{background:var(--surface);border-radius:12px;padding:28px;max-width:420px;width:90%;box-shadow:0 8px 32px rgba(0,0,0,.25)}}
.modal h2{{margin-bottom:16px;font-size:1.2rem}}
.modal-stats{{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:20px}}
.modal-stat{{background:var(--surface2);border-radius:8px;padding:12px;text-align:center}}
.modal-stat .val{{font-size:1.4rem;font-weight:700}}
.modal-stat .lbl{{font-size:.75rem;color:var(--text2);margin-top:2px}}
.modal-actions{{display:flex;gap:10px}}
.btn-confirm-submit{{flex:1;padding:11px;background:var(--success);color:#fff;border-radius:6px;font-weight:700}}
.btn-cancel-submit{{flex:1;padding:11px;background:var(--surface2);color:var(--text);border-radius:6px;font-weight:600;border:1px solid var(--border)}}

/* ═══════════════════════════════════════════
   RESULT SCREEN
═══════════════════════════════════════════ */
#result-screen{{align-items:center;justify-content:center;padding:20px;background:var(--bg)}}
.result-card{{background:var(--surface);border-radius:12px;box-shadow:var(--shadow);max-width:720px;width:100%;overflow:hidden}}
.result-header{{background:var(--primary);color:#fff;padding:24px;text-align:center}}
.result-header h1{{font-size:1.4rem}}
.score-circle{{width:130px;height:130px;border-radius:50%;background:rgba(255,255,255,.15);border:4px solid rgba(255,255,255,.5);display:flex;flex-direction:column;align-items:center;justify-content:center;margin:16px auto 0}}
.score-circle .score-val{{font-size:2.2rem;font-weight:800}}
.score-circle .score-max{{font-size:.85rem;opacity:.8}}
.result-meta{{padding:20px;display:grid;grid-template-columns:repeat(3,1fr);gap:12px;border-bottom:1px solid var(--border)}}
@media(max-width:480px){{.result-meta{{grid-template-columns:1fr 1fr}}}}
.result-stat{{text-align:center;padding:12px;background:var(--surface2);border-radius:8px}}
.result-stat .rv{{font-size:1.5rem;font-weight:700}}
.result-stat .rl{{font-size:.75rem;color:var(--text2)}}
.result-stat.correct .rv{{color:var(--success)}}
.result-stat.wrong .rv{{color:var(--danger)}}
.result-stat.unattempted .rv{{color:var(--text2)}}
.pass-badge{{display:inline-block;padding:6px 18px;border-radius:20px;font-weight:700;font-size:.9rem;margin:16px auto;display:block;width:max-content;margin:16px auto}}
.pass-badge.pass{{background:#e8f5e9;color:#2e7d32}}
.pass-badge.fail{{background:#ffebee;color:#c62828}}

/* Analysis Table */
.analysis-section{{padding:20px}}
.analysis-section h3{{font-size:1rem;margin-bottom:12px;color:var(--primary)}}
.analysis-table{{width:100%;border-collapse:collapse;font-size:.85rem}}
.analysis-table th{{background:var(--surface2);padding:10px 12px;text-align:left;border-bottom:2px solid var(--border)}}
.analysis-table td{{padding:10px 12px;border-bottom:1px solid var(--border)}}
.analysis-table tr:last-child td{{border:none}}
.tag-correct{{color:var(--success);font-weight:700}}
.tag-wrong{{color:var(--danger);font-weight:700}}
.tag-skip{{color:var(--text2)}}
.result-actions{{padding:20px;display:flex;gap:10px;flex-wrap:wrap;border-top:1px solid var(--border)}}
.btn-retake{{flex:1;min-width:140px;padding:11px;background:var(--primary);color:#fff;border-radius:6px;font-weight:700;text-align:center}}
.btn-download-result{{flex:1;min-width:140px;padding:11px;background:var(--surface2);color:var(--text);border-radius:6px;font-weight:600;border:1px solid var(--border);text-align:center}}

/* ── Responsive ── */
@media(max-width:768px){{
  .palette-panel{{display:none;position:fixed;inset:0;z-index:150;width:100%;border-left:none}}
  .palette-panel.open{{display:flex;flex-direction:column}}
  .show-palette-btn{{display:flex}}
  .btn-action{{font-size:.8rem;padding:8px 12px}}
}}
.show-palette-btn{{display:none;align-items:center;gap:6px;background:rgba(255,255,255,.15);border:none;color:#fff;padding:6px 10px;border-radius:6px;font-size:.85rem}}
.close-palette-btn{{display:none}}
@media(max-width:768px){{
  .close-palette-btn{{display:block;margin:8px 12px;padding:8px;background:var(--surface2);border-radius:6px;border:1px solid var(--border);font-size:.85rem}}
}}
</style>
</head>
<body>

<!-- ══════════════════════ INSTRUCTIONS SCREEN ══════════════════════ -->
{instructions_html}

<!-- ══════════════════════ EXAM SCREEN ══════════════════════ -->
<div id="exam-screen" class="screen">
  <header class="exam-header">
    <button class="show-palette-btn" onclick="togglePalette()" aria-label="Question palette">
      ☰ <span id="palette-btn-text">Palette</span>
    </button>
    <div class="exam-title" id="exam-title-header"></div>
    <div class="timer-box" id="timer">⏱ 00:00</div>
    <button class="fullscreen-btn" onclick="toggleFullscreen()" title="Fullscreen">⛶</button>
  </header>

  <div class="subject-tabs" id="subject-tabs">
    <button class="subject-tab active" onclick="switchSubject(0)">All Questions</button>
  </div>

  <div class="exam-body">
    <!-- Question Panel -->
    <div class="question-panel" id="question-panel">
      <div class="q-area" id="q-area">
        <!-- Injected by JS -->
      </div>
      <div class="q-actions">
        <button class="btn-action btn-save-next" onclick="saveAndNext()">💾 Save &amp; Next</button>
        <button class="btn-action btn-mark-review" onclick="markForReview()">🔖 Mark for Review</button>
        <button class="btn-action btn-clear" onclick="clearResponse()">🗑 Clear</button>
        <button class="btn-action btn-prev" onclick="navigate(-1)">◀ Prev</button>
        <button class="btn-action btn-next" onclick="navigate(1)">Next ▶</button>
        <button class="btn-action btn-submit-main" onclick="openSubmitModal()">Submit ✔</button>
      </div>
    </div>

    <!-- Palette Panel -->
    <div class="palette-panel" id="palette-panel">
      <button class="close-palette-btn" onclick="togglePalette()">✕ Close Palette</button>
      <div class="palette-header">Question Palette</div>
      <div class="palette-legend">
        <div class="pal-stat"><div class="pal-dot" style="background:#4caf50"></div>Answered</div>
        <div class="pal-stat"><div class="pal-dot" style="background:#9c27b0"></div>Review</div>
        <div class="pal-stat"><div class="pal-dot" style="background:#ff9800"></div>Ans+Rev</div>
        <div class="pal-stat"><div class="pal-dot" style="background:#e0e0e0"></div>Not visited</div>
      </div>
      <div class="palette-grid" id="palette-grid"></div>
      <div class="palette-footer">
        <button class="btn-submit-pal" onclick="openSubmitModal()">Submit Test</button>
      </div>
    </div>
  </div>
</div>

<!-- ══════════════════════ SUBMIT MODAL ══════════════════════ -->
<div class="modal-overlay" id="submit-modal">
  <div class="modal">
    <h2>📋 Submit Test?</h2>
    <div class="modal-stats">
      <div class="modal-stat"><div class="val" id="m-answered">0</div><div class="lbl">Answered</div></div>
      <div class="modal-stat"><div class="val" id="m-marked">0</div><div class="lbl">Marked Review</div></div>
      <div class="modal-stat"><div class="val" id="m-not-answered">0</div><div class="lbl">Not Answered</div></div>
      <div class="modal-stat"><div class="val" id="m-not-visited">0</div><div class="lbl">Not Visited</div></div>
    </div>
    <div class="modal-actions">
      <button class="btn-cancel-submit" onclick="closeSubmitModal()">Cancel</button>
      <button class="btn-confirm-submit" onclick="submitTest()">Submit Now</button>
    </div>
  </div>
</div>

<!-- ══════════════════════ RESULT SCREEN ══════════════════════ -->
<div id="result-screen" class="screen">
  <div class="result-card">
    <div class="result-header">
      <h1 id="res-title">Test Result</h1>
      <div class="score-circle">
        <div class="score-val" id="res-score">0</div>
        <div class="score-max" id="res-max">/ 0</div>
      </div>
    </div>
    <div style="text-align:center;padding:8px 0">
      <span class="pass-badge" id="pass-badge"></span>
    </div>
    <div class="result-meta" id="result-meta"></div>
    <div class="analysis-section">
      <h3>📊 Detailed Analysis</h3>
      <table class="analysis-table">
        <thead>
          <tr><th>#</th><th>Question</th><th>Your Answer</th><th>Correct</th><th>Status</th><th>Marks</th></tr>
        </thead>
        <tbody id="analysis-body"></tbody>
      </table>
    </div>
    <div class="result-actions">
      <button class="btn-retake" onclick="retakeTest()">🔄 Retake Test</button>
      <button class="btn-download-result" onclick="window.print()">🖨 Print Result</button>
    </div>
  </div>
</div>

<!-- ══════════════════════ JAVASCRIPT ══════════════════════ -->
<script>
// ── Data injected from Python ──────────────────────────────
const QUESTIONS = {questions_json};
const CONFIG    = {config_json};

// ── State ─────────────────────────────────────────────────
let currentIndex   = 0;
let timerInterval  = null;
let timeLeft       = CONFIG.totalTimeSeconds;
const answers      = new Array(QUESTIONS.length).fill(-1);  // -1 = no answer
const status       = new Array(QUESTIONS.length).fill('not-visited');
// status values: 'not-visited' | 'not-answered' | 'answered' | 'review' | 'answered-review'

// ── Boot ──────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {{
  applyTheme();
  const instrScreen = document.getElementById('instructions-screen');
  if (instrScreen) {{
    showScreen('instructions');
  }} else {{
    startExam();
  }}
}});

function applyTheme() {{
  if (CONFIG.darkMode) {{
    document.documentElement.setAttribute('data-theme', 'dark');
  }}
}}

function showScreen(name) {{
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const el = document.getElementById(name + '-screen');
  if (el) el.classList.add('active');
  window.scrollTo(0, 0);
}}

function startExam() {{
  document.getElementById('exam-title-header').textContent = CONFIG.title;
  buildPalette();
  renderQuestion(0);
  startTimer();
  showScreen('exam');
}}

// ── Timer ─────────────────────────────────────────────────
function startTimer() {{
  updateTimerDisplay();
  timerInterval = setInterval(() => {{
    timeLeft--;
    updateTimerDisplay();
    if (timeLeft <= 300) {{
      document.getElementById('timer').classList.add('warning');
    }}
    if (timeLeft <= 0) {{
      clearInterval(timerInterval);
      submitTest();
    }}
  }}, 1000);
}}

function updateTimerDisplay() {{
  const h = Math.floor(timeLeft / 3600);
  const m = Math.floor((timeLeft % 3600) / 60);
  const s = timeLeft % 60;
  const parts = h > 0
    ? [pad(h), pad(m), pad(s)]
    : [pad(m), pad(s)];
  document.getElementById('timer').textContent = '⏱ ' + parts.join(':');
}}

function pad(n) {{ return String(n).padStart(2,'0'); }}

// ── Render Question ───────────────────────────────────────
function renderQuestion(index) {{
  currentIndex = Math.max(0, Math.min(index, QUESTIONS.length - 1));
  const q = QUESTIONS[currentIndex];
  const area = document.getElementById('q-area');

  // Mark visited
  if (status[currentIndex] === 'not-visited') {{
    status[currentIndex] = 'not-answered';
  }}

  const optLetters = ['A','B','C','D'];
  const selectedAns = answers[currentIndex];

  area.innerHTML = `
    <div class="q-meta">Question ${{currentIndex + 1}} of ${{QUESTIONS.length}} &nbsp;|&nbsp; +1 Mark ${{CONFIG.negativeMarking > 0 ? ' | -' + CONFIG.negativeMarking + ' Negative' : ''}}</div>
    <div class="q-number-badge">Q.${{currentIndex + 1}}</div>
    <div class="q-text">${{escHtml(q.text)}}</div>
    <div class="options-list">
      ${{q.options.map((opt, i) => `
        <div class="option ${{selectedAns === i ? 'selected' : ''}}" onclick="selectOption(${{i}})">
          <div class="option-label">${{optLetters[i]}}</div>
          <div class="option-text">${{escHtml(opt)}}</div>
        </div>
      `).join('')}}
    </div>
  `;

  updatePalette();
}}

function escHtml(str) {{
  return String(str)
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}}

// ── Option Selection ──────────────────────────────────────
function selectOption(optIndex) {{
  answers[currentIndex] = optIndex;
  if (status[currentIndex] === 'not-answered' || status[currentIndex] === 'not-visited') {{
    status[currentIndex] = 'answered';
  }} else if (status[currentIndex] === 'review') {{
    status[currentIndex] = 'answered-review';
  }}
  renderQuestion(currentIndex);
}}

// ── Navigation ────────────────────────────────────────────
function navigate(dir) {{
  renderQuestion(currentIndex + dir);
  closePaletteOnMobile();
}}

function saveAndNext() {{
  if (answers[currentIndex] !== -1) {{
    status[currentIndex] = 'answered';
  }}
  renderQuestion(currentIndex + 1);
}}

function markForReview() {{
  if (answers[currentIndex] !== -1) {{
    status[currentIndex] = 'answered-review';
  }} else {{
    status[currentIndex] = 'review';
  }}
  renderQuestion(currentIndex + 1);
}}

function clearResponse() {{
  answers[currentIndex] = -1;
  status[currentIndex] = 'not-answered';
  renderQuestion(currentIndex);
}}

// ── Palette ───────────────────────────────────────────────
function buildPalette() {{
  const grid = document.getElementById('palette-grid');
  grid.innerHTML = QUESTIONS.map((_, i) =>
    `<button class="pal-btn not-visited" id="pb-${{i}}" onclick="jumpTo(${{i}})">${{i + 1}}</button>`
  ).join('');
}}

function updatePalette() {{
  QUESTIONS.forEach((_, i) => {{
    const btn = document.getElementById('pb-' + i);
    if (!btn) return;
    btn.className = 'pal-btn ' + status[i];
    if (i === currentIndex) btn.classList.add('current');
  }});
}}

function jumpTo(index) {{
  renderQuestion(index);
  closePaletteOnMobile();
}}

function togglePalette() {{
  document.getElementById('palette-panel').classList.toggle('open');
}}

function closePaletteOnMobile() {{
  if (window.innerWidth <= 768) {{
    document.getElementById('palette-panel').classList.remove('open');
  }}
}}

// ── Submit Modal ──────────────────────────────────────────
function openSubmitModal() {{
  const counts = getStatusCounts();
  document.getElementById('m-answered').textContent     = counts.answered + counts.answeredReview;
  document.getElementById('m-marked').textContent       = counts.review + counts.answeredReview;
  document.getElementById('m-not-answered').textContent = counts.notAnswered;
  document.getElementById('m-not-visited').textContent  = counts.notVisited;
  document.getElementById('submit-modal').classList.add('open');
}}

function closeSubmitModal() {{
  document.getElementById('submit-modal').classList.remove('open');
}}

function getStatusCounts() {{
  return {{
    answered:       status.filter(s => s === 'answered').length,
    answeredReview: status.filter(s => s === 'answered-review').length,
    review:         status.filter(s => s === 'review').length,
    notAnswered:    status.filter(s => s === 'not-answered').length,
    notVisited:     status.filter(s => s === 'not-visited').length,
  }};
}}

// ── Submit & Result ───────────────────────────────────────
function submitTest() {{
  clearInterval(timerInterval);
  closeSubmitModal();

  let correct = 0, wrong = 0, skipped = 0;
  let score = 0;

  const tbody = document.getElementById('analysis-body');
  const rows = QUESTIONS.map((q, i) => {{
    const userAns = answers[i];
    const optLetters = ['A','B','C','D'];
    let rowStatus, rowClass, marksStr;

    if (userAns === -1) {{
      skipped++;
      rowStatus = '<span class="tag-skip">Skipped</span>';
      rowClass  = '';
      marksStr  = '0';
    }} else if (userAns === q.correct) {{
      correct++;
      score += 1;
      rowStatus = '<span class="tag-correct">✓ Correct</span>';
      rowClass  = 'tag-correct';
      marksStr  = '+1';
    }} else {{
      wrong++;
      score -= CONFIG.negativeMarking;
      rowStatus = '<span class="tag-wrong">✗ Wrong</span>';
      rowClass  = '';
      marksStr  = CONFIG.negativeMarking > 0 ? '-' + CONFIG.negativeMarking : '0';
    }}

    return `<tr>
      <td>${{i + 1}}</td>
      <td style="max-width:220px;font-size:.8rem">${{escHtml(q.text.substring(0,80))}}${{q.text.length>80?'…':''}}</td>
      <td>${{userAns === -1 ? '—' : optLetters[userAns]}}</td>
      <td class="tag-correct">${{optLetters[q.correct]}}</td>
      <td>${{rowStatus}}</td>
      <td style="font-weight:700;color:inherit">${{marksStr}}</td>
    </tr>`;
  }});
  tbody.innerHTML = rows.join('');

  const totalMarks  = QUESTIONS.length;
  const finalScore  = Math.max(0, score);
  const passed      = finalScore >= CONFIG.passingMarks;

  document.getElementById('res-title').textContent = CONFIG.title + ' — Result';
  document.getElementById('res-score').textContent = finalScore.toFixed(CONFIG.negativeMarking > 0 ? 2 : 0);
  document.getElementById('res-max').textContent   = '/ ' + totalMarks;

  const badge = document.getElementById('pass-badge');
  badge.textContent = passed ? '🎉 PASSED' : '❌ FAILED';
  badge.className   = 'pass-badge ' + (passed ? 'pass' : 'fail');

  const attempted = correct + wrong;
  const accuracy  = attempted > 0 ? ((correct / attempted) * 100).toFixed(1) : '0.0';

  document.getElementById('result-meta').innerHTML = `
    <div class="result-stat correct"><div class="rv">${{correct}}</div><div class="rl">Correct</div></div>
    <div class="result-stat wrong"><div class="rv">${{wrong}}</div><div class="rl">Wrong</div></div>
    <div class="result-stat unattempted"><div class="rv">${{skipped}}</div><div class="rl">Skipped</div></div>
    <div class="result-stat"><div class="rv">${{attempted}}</div><div class="rl">Attempted</div></div>
    <div class="result-stat"><div class="rv">${{accuracy}}%</div><div class="rl">Accuracy</div></div>
    <div class="result-stat"><div class="rv">${{CONFIG.passingMarks}}</div><div class="rl">Passing Marks</div></div>
  `;

  showScreen('result');
}}

function retakeTest() {{
  answers.fill(-1);
  status.fill('not-visited');
  timeLeft = CONFIG.totalTimeSeconds;
  startTimer();
  renderQuestion(0);
  showScreen('exam');
}}

// ── Fullscreen ────────────────────────────────────────────
function toggleFullscreen() {{
  if (!document.fullscreenElement) {{
    document.documentElement.requestFullscreen?.();
  }} else {{
    document.exitFullscreen?.();
  }}
}}
</script>
</body>
</html>"""

    return html


def _build_instructions(config: TestConfig) -> str:
    return f"""
<div id="instructions-screen" class="screen active">
  <div class="instr-card">
    <div class="instr-header">
      <h1>📋 {config.title}</h1>
      <p>{config.subject} &nbsp;|&nbsp; MockTest Pro</p>
    </div>
    <div class="instr-meta">
      <span>⏱ <strong>Duration:</strong> {config.total_time_minutes} min</span>
      <span>❓ <strong>Questions:</strong> <span id="q-count-instr">—</span></span>
      <span>✅ <strong>Marks/Q:</strong> +1</span>
      <span>❌ <strong>Negative:</strong> {f'-{config.negative_marking}' if config.negative_marking else 'None'}</span>
      <span>🎯 <strong>Passing:</strong> {config.passing_marks}</span>
    </div>
    <div class="instr-body">
      <h3>📌 General Instructions</h3>
      <ul>
        <li>This test contains objective type (MCQ) questions.</li>
        <li>Each question carries <strong>1 mark</strong> for correct answer.</li>
        {'<li>There is <strong>negative marking of ' + str(config.negative_marking) + '</strong> for each wrong answer.</li>' if config.negative_marking else '<li>There is <strong>no negative marking</strong> in this test.</li>'}
        <li>The timer will start as soon as you click <strong>Start Test</strong>.</li>
        <li>You can navigate between questions using <em>Prev / Next</em> buttons or the Question Palette.</li>
        <li>Use <strong>Save &amp; Next</strong> to save your answer and move to the next question.</li>
        <li>Use <strong>Mark for Review</strong> to flag a question for later review.</li>
        <li>You can change your answer at any time before submission.</li>
        <li>The test will auto-submit when the timer reaches zero.</li>
      </ul>
      <div class="legend">
        <div class="legend-item"><div class="legend-dot" style="background:#4caf50">✓</div> Answered</div>
        <div class="legend-item"><div class="legend-dot" style="background:#9c27b0">R</div> Marked for Review</div>
        <div class="legend-item"><div class="legend-dot" style="background:#ff9800">R</div> Answered + Review</div>
        <div class="legend-item"><div class="legend-dot" style="background:#e0e0e0;color:#333">—</div> Not Visited</div>
      </div>
      <button class="start-btn" onclick="startExam()">▶ Start Test</button>
    </div>
  </div>
</div>
<script>
  // Show real question count once data is loaded
  document.addEventListener('DOMContentLoaded', () => {{
    const el = document.getElementById('q-count-instr');
    if (el) el.textContent = QUESTIONS.length;
  }});
</script>
"""


def save_html_file(html: str, user_id: int, test_id: int, title: str) -> Path:
    """Write HTML to disk and return the path."""
    from config import GENERATED_TESTS_DIR
    safe_title = "".join(c for c in title if c.isalnum() or c in " _-")[:40].strip().replace(" ", "_")
    filename = f"test_{user_id}_{test_id}_{safe_title}.html"
    path = GENERATED_TESTS_DIR / filename
    path.write_text(html, encoding="utf-8")
    logger.info("HTML saved: %s", path)
    return path
