from .html_generator import generate_html, save_html_file, TestConfig

__all__ = ["generate_html", "save_html_file", "TestConfig"]
