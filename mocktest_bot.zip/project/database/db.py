"""
database/db.py - SQLite database layer.
Handles user records and generated test metadata.
"""

import sqlite3
import logging
from datetime import datetime
from pathlib import Path
from contextlib import contextmanager

import sys, os
sys.path.insert(0, str(Path(__file__).parent.parent))
from config import DATABASE_PATH

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────
# Connection helper
# ─────────────────────────────────────────────

@contextmanager
def get_connection():
    """Thread-safe SQLite connection context manager."""
    conn = sqlite3.connect(str(DATABASE_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ─────────────────────────────────────────────
# Schema initialisation
# ─────────────────────────────────────────────

def init_db() -> None:
    """Create tables if they don't already exist."""
    with get_connection() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                user_id     INTEGER PRIMARY KEY,
                username    TEXT,
                first_name  TEXT,
                last_name   TEXT,
                joined_at   TEXT NOT NULL,
                last_seen   TEXT NOT NULL,
                total_tests INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS tests (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER NOT NULL REFERENCES users(user_id),
                title       TEXT NOT NULL,
                subject     TEXT,
                filename    TEXT NOT NULL,
                created_at  TEXT NOT NULL,
                question_count INTEGER NOT NULL DEFAULT 0,
                config_json TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_tests_user ON tests(user_id);
        """)
    logger.info("Database initialised at %s", DATABASE_PATH)


# ─────────────────────────────────────────────
# User helpers
# ─────────────────────────────────────────────

def upsert_user(user_id: int, username: str | None,
                first_name: str, last_name: str | None) -> None:
    now = datetime.utcnow().isoformat()
    with get_connection() as conn:
        existing = conn.execute(
            "SELECT user_id FROM users WHERE user_id = ?", (user_id,)
        ).fetchone()
        if existing:
            conn.execute(
                """UPDATE users
                   SET username=?, first_name=?, last_name=?, last_seen=?
                   WHERE user_id=?""",
                (username, first_name, last_name, now, user_id),
            )
        else:
            conn.execute(
                """INSERT INTO users
                       (user_id, username, first_name, last_name, joined_at, last_seen)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (user_id, username, first_name, last_name, now, now),
            )


def get_user_tests(user_id: int) -> list[sqlite3.Row]:
    with get_connection() as conn:
        return conn.execute(
            """SELECT id, title, subject, created_at, question_count
               FROM tests
               WHERE user_id = ?
               ORDER BY created_at DESC
               LIMIT 20""",
            (user_id,),
        ).fetchall()


# ─────────────────────────────────────────────
# Test helpers
# ─────────────────────────────────────────────

def save_test(user_id: int, title: str, subject: str,
              filename: str, question_count: int, config_json: str) -> int:
    now = datetime.utcnow().isoformat()
    with get_connection() as conn:
        cursor = conn.execute(
            """INSERT INTO tests
                   (user_id, title, subject, filename, created_at, question_count, config_json)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (user_id, title, subject, filename, now, question_count, config_json),
        )
        conn.execute(
            "UPDATE users SET total_tests = total_tests + 1, last_seen = ? WHERE user_id = ?",
            (now, user_id),
        )
        return cursor.lastrowid
